<?php
$conn = mysqli_connect("localhost","root","","fees_institute");
?>
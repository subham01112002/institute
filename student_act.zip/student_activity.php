<?php 
   include("conn.php");
   session_start();
   
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(!isset($_SESSION['id']))
     {
      @header("Location: index.php");
          
     }   
          $mspg = $_SESSION['id'];  
          $name = $_SESSION['name'];
   
    $req=" SELECT * FROM  `subject_category` ORDER BY `Category_id`";
    $qut=mysqli_query($conn,$req);

    $rem=" SELECT * FROM  `subject_group` ORDER BY `Subject_group_id`";
    $que=mysqli_query($conn,$rem);

    $ren=" SELECT * FROM  `subject_master` ORDER BY `Subject_id`";
    $quy=mysqli_query($conn,$ren);

    

    $rel=" SELECT * FROM  `teacher` ORDER BY `Teacher_id`";
    $qup=mysqli_query($conn,$rel);

    if(!empty($_REQUEST['add']) && !empty($_REQUEST['mode'])){
      $res_studentid = $mspg; 
      $res_studentname = $name;
      $res_Categoryid = $_REQUEST['Category_id'];
      $res_Subject_groupid = $_REQUEST['Subject_group_id'];
      $res_Subjectid = $_REQUEST['Subject_id'];
      $res_Teacher_id = $_REQUEST['Teacher_id'];
      $res_Actual_fees = $_REQUEST['Actual_fees']; 
      $res_Joining_date = $_REQUEST['Joining_date'];
      $res_Month = $_REQUEST['Month'];
      
      
      $sql_con="INSERT INTO `student_activity` SET 
              `Student_id`='$res_studentid' ,
              `Category_id`= '$res_Categoryid',
              `Subject_group_id`= '$res_Subject_groupid',
              `Subject_id`= '$res_Subjectid', 
              
              `Actual_fees`='$res_Actual_fees' ,
              `Joining_date`= '$res_Joining_date', 
              `Month`= '$res_Month' ,
              `Teacher_id`= '$res_Teacher_id'  ";  
      $res=mysqli_query($conn, $sql_con);
      if($res)
        {
          @header("Location: student_activity.php");
		      exit();   		
        }
    }

    if(!empty($_REQUEST['mode']))
    {  
      $res_studentid = $mspg; 
      $res_studentname = $name;
      $res_Categoryid = $_REQUEST['Category_id'];
      $res_Subject_groupid = $_REQUEST['Subject_group_id'];
      $res_Subjectid = $_REQUEST['Subject_id'];
      $res_Teacher_id = $_REQUEST['Teacher_id'];
      $res_Actual_fees = $_REQUEST['Actual_fees']; 
      $res_Joining_date = $_REQUEST['Joining_date'];
      $res_Month = $_REQUEST['Month'];
      

      
      $sqll="INSERT INTO `student_activity` SET 
              `Student_id`='$res_studentid' ,
              `Student_name`='$res_studentname',
              `Category_id`= '$res_Categoryid',
              `Subject_group_id`= '$res_Subject_groupid',
              `Subject_id`= '$res_Subjectid', 
              
              `Actual_fees`='$res_Actual_fees' ,
              `Joining_date`= '$res_Joining_date', 
              `Month`= '$res_Month' ,
              `Teacher_id`= '$res_Teacher_id'  ";  
      $rqs=mysqli_query($conn, $sqll);
      
      if($rqs)
        {
          unset($_SESSION['id']);
          unset($_SESSION['name']);
          session_destroy();
          @header("Location: student_registration.php?msg=Successfull Insert");
		      exit();   		
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href="student_act.css" >
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Document</title>
    <script language="javascript" type="text/javascript">
		function checking()
		{
				if(document.getElementById('Student_name').value=='')
				{
					alert('Please enter your id!');
					document.paymentform.Student_name.focus();
					return false;
				}
        if(document.getElementById('Category_id').value=='')
				{
					alert('Please enter subject category!');
					document.paymentform.Category_id.focus();
					return false;
				}	
        if(document.getElementById('Subject_group_id').value=='')
				{
					alert('Please enter subject category!');
					document.paymentform.Subject_group_id.focus();
					return false;
				}	
				if(document.getElementById('Subject_id').value=='')
				{
					alert('Please enter your subject !');
					document.paymentform.Subject_id.focus();
					return false;
				}
				
				
        if(document.getElementById('Actual_fees').value=='')
				{
					alert('Please enter fees!');
					document.paymentform.Actual_fees.focus();
					return false;
				}	
        if(document.getElementById('Joining_date').value=='')
				{
					alert('Please enter admission date!');
					document.paymentform.Joining_date.focus();
					return false;
				}	
        if(document.getElementById('Month').value=='')
				{
					alert('Please enter current month!');
					document.paymentform.Month.focus();
					return false;
				}	
        if(document.getElementById('Teacher_id').value=='')
				{
					alert('Please enter teacher name!');
					document.paymentform.Teacher_id.focus();
					return false;
				}		
		}
	</script>
</head>
<body>
<div class="form-box">
  <h1><i class="fa-solid fa-building-columns"></i></h1>
  <h1>Student Activity Form</h1>
  
  <form action="" name="paymentform" id="paymentform" method="post" onSubmit="return checking();">
    <input type="hidden" name="mode" value="1" />
    
    <div class="form-group">
      <label for="studentid">Student Name</label>
      <input class="form-control" id="Student_name" type="text" name="Student_name" value="<?php echo $name ?>"/>
    </div>
    <div class="form-group">
      <label for="categoryid">Category Name</label>
      <select class="form-control" name="Category_id" id="Category_id" >
									<option value=""> Select Your Category</option>
									<?php while($c=mysqli_fetch_array($qut)){ ?>
									<option value="<?php echo $c['Category_id'] ?>"><?php echo $c['Category_name'] ?></option>
                  <?php } ?>
	    </select>
    </div>
    <div class="form-group">
      <label for="categoryid">Subject Group Name</label>
      <select class="form-control" name="Subject_group_id" id="Subject_group_id" >
									<option value=""> Select Your subject group</option>
									<?php while($c=mysqli_fetch_array($que)){ ?>
									<option value="<?php echo $c['Subject_group_id'] ?>"><?php echo $c['Subject_group_name'] ?></option>
                  <?php } ?>
	    </select>
    </div>
    <div class="form-group">
      <label for="subjectid">Subject Name</label>
      <select class="form-control" name="Subject_id" id="Subject_id" >
									<option value=""> Select your subject</option>
									<?php while($b=mysqli_fetch_array($quy)){ ?>
									<option value="<?php echo $b['Subject_id'] ?>"><?php echo $b['Subject_name'] ?></option>
                  <?php } ?>
	    </select>
    </div>
    <div class="form-group">
    <label for="teacherid">Teacher Name</label>
      <select class="form-control" name="Teacher_id" id="Teacher_id" >
									<option value="">Select teacher</option>
									<?php while($d=mysqli_fetch_array($qup)){ ?>
									<option value="<?php echo $d['Teacher_id'] ?>"><?php echo $d['Teacher_name'] ?></option>
                  <?php } ?>
	    </select>    
    </div>
    <div class="form-group">
      <label for="fees">Actual Fees</label>
      <input class="form-control" id="Actual_fees" type="int" name="Actual_fees"/>
    </div>
    <div class="form-group">
      <label for="joining-date">Admission Date</label>
      <input class="form-control" id="Joining_date" type="date" name="Joining_date"/>
    </div>
    <div class="form-group">
      <label for="Month">Current Month</label>
      <input class="form-control" id="Month" type="month" name="Month"/>
    </div>
      
    
    <div class="but">
      <input class="btn btn-primary" type="submit" name="add" value="+" /><br> 
    </div>
    <div class="but">
        <input class="btn btn-primary" type="submit" value="Submit" /><br>
    </div>
    
  </form>
 <!-- <table border="0" align="center"  >
		<tr>
			<td style="color:#FF0000;">&nbsp;</td>   			 
		</tr>-->
</table>
</div>
</body>
</html>